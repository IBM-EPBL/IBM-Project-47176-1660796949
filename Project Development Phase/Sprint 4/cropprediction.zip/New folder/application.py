from flask import Flask,render_template,template_rendered,request,redirect,url_for,session
import csv


rows = []
with open("file.csv", 'r') as file:
    csvreader = csv.reader(file)
    header = next(csvreader)
    for row in csvreader:
        rows.append(row)

app = Flask(__name__)


@app.route('/',methods=['GET','POST'])
def hello_world():
    if request.method == "GET":
        if request.args.get('district') and request.args.get('season'):
            return render_template("index.html",value=rows,len=len(rows), d = request.args.get('district'), se = request.args.get('season'),  s= session["name"])
        else:
            return render_template("index.html",value=rows,len=len(rows),s = "",d = "")
    else:
        session['name'] = request.form["State"]
        
        return render_template("index.html",value=rows,len=len(rows), s = session["name"] ,d = "")
        # return redirect(url_for('index.html',s = state))

if __name__ == "__main__":
    app.secret_key = 'super secret key'
    app.config['SESSION_TYPE'] = 'filesystem'

    # sess.init_app(app)

    app.debug = True
    app.run(debug=True)